#include <jni.h>
/* Header for jnetpcap_utils utility methods */

#ifndef _Included_org_jnetpcap_WinPcapExtensions
#define _Included_org_jnetpcap_WinPcapExtensions
#ifdef __cplusplus
extern "C" {
#define	EXTERN extern "C"
#endif
	
extern	jclass winPcapClass;

// Prototypes

#ifdef __cplusplus
}
#endif
#endif
